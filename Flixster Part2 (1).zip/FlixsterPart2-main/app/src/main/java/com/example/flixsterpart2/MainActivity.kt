package com.example.flixsterpart2

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL
import com.example.flixsterpart2.databinding.ActivityMainBinding
import com.codepath.asynchttpclient.AsyncHttpClient
import com.codepath.asynchttpclient.callback.JsonHttpResponseHandler
import kotlinx.serialization.json.Json
import okhttp3.Headers

fun createJson() = Json {
    isLenient = true
    ignoreUnknownKeys = true
    useAlternativeNames = false
}

private const val TAG = "MainActivity"
private const val BASE_URL = "https://api.themoviedb.org/3"
private const val API_KEY = BuildConfig.API_KEY
private const val MOVIE_SEARCH_URL = "$BASE_URL/movie/top_rated?api_key=$API_KEY"
private const val TV_SEARCH_URL = "$BASE_URL/tv/top_rated?api_key=$API_KEY"

class MainActivity : AppCompatActivity() {

    private val movies = mutableListOf<Movie>()
    private val tvs = mutableListOf<Tv>()
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerViews()

        fetchData(MOVIE_SEARCH_URL) { json ->
            val parsedJson = createJson().decodeFromString(BaseResponse.serializer(), json.jsonObject.toString())
            parsedJson.result?.let { list ->
                movies.addAll(list)
                binding.topMovieRecyclerView.adapter?.notifyDataSetChanged()
            }
        }

        fetchData(TV_SEARCH_URL) { json ->
            val parsedJson = createJson().decodeFromString(TvBaseResponse.serializer(), json.jsonObject.toString())
            parsedJson.result?.let { list ->
                tvs.addAll(list)
                binding.topTvRecyclerView.adapter?.notifyDataSetChanged()
            }
        }
    }

    private fun setupRecyclerViews() {
        binding.topMovieRecyclerView.apply {
            adapter = MovieAdapter(this@MainActivity, movies)
            layoutManager = LinearLayoutManager(this@MainActivity, HORIZONTAL, false)
        }

        binding.topTvRecyclerView.apply {
            adapter = TvAdapter(this@MainActivity, tvs)
            layoutManager = LinearLayoutManager(this@MainActivity, HORIZONTAL, false)
        }
    }

    private fun fetchData(url: String, onSuccess: (json: JsonHttpResponseHandler.JSON) -> Unit) {
        val client = AsyncHttpClient()
        client.get(url, object : JsonHttpResponseHandler() {
            override fun onFailure(statusCode: Int, headers: Headers?, response: String?, throwable: Throwable?) {
                Log.e(TAG, "Failed to fetch data: $statusCode")
            }

            override fun onSuccess(statusCode: Int, headers: Headers, json: JSON) {
                Log.i(TAG, "Successfully fetched data: $json")
                onSuccess(json)
            }
        })
    }
}
