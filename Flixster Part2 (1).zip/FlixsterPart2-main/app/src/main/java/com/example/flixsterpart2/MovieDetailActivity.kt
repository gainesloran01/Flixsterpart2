package com.example.flixsterpart2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.example.flixsterpart2.databinding.DetailMovieBinding

private const val TAG = "MovieDetailActivity"

class MovieDetailActivity : AppCompatActivity() {
    private lateinit var binding: DetailMovieBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DetailMovieBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val movie = intent.getSerializableExtra(MOVIE_EXTRA) as? Movie
        movie?.let {
            bindMovieDetails(it)
        } ?: finish() // Close activity if movie is null
    }

    private fun bindMovieDetails(movie: Movie) {
        binding.apply {
            mediaTitle.text = movie.title
            mediaRate.text = getString(R.string.rate_label, movie.vote.toString())
            mediaRateCount.text = getString(R.string.rate_count_label, movie.count.toString())
            mediaReleaseDate.text = getString(R.string.release_date_label, movie.release_date)
            mediaOverview.text = getString(R.string.overview_label, movie.overview)

            val imageUrl = getString(R.string.image_base_url) + movie.poster_path
            Glide.with(this@MovieDetailActivity)
                .load(imageUrl)
                .centerCrop()
                .transform(RoundedCorners(resources.getDimensionPixelSize(R.dimen.rounded_corner_radius)))
                .into(mediaImage)
        }
    }
}
