package com.example.flixsterpart2

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.example.flixsterpart2.databinding.ItemTvBinding

const val TV_EXTRA = "TV_EXTRA"
private const val TAG = "TvAdapter"

/**
 * Adapter for displaying a list of TV shows in a RecyclerView.
 * @param context Context used for various operations.
 * @param tvs List of TV shows to display.
 */
class TvAdapter(private val context: Context, private val tvs: List<Tv>) :
    RecyclerView.Adapter<TvAdapter.ViewHolder>() {

    // Inflate the layout for each item and return a ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemTvBinding.inflate(LayoutInflater.from(context), parent, false)
        return ViewHolder(binding)
    }

    // Bind data for the TV show at the given position
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tv = tvs[position]
        holder.bind(tv)
    }

    // Return the number of TV shows in the dataset
    override fun getItemCount() = tvs.size

    /**
     * ViewHolder class for individual TV show items.
     * @param binding ViewBinding instance for the TV show item.
     */
    inner class ViewHolder(private val binding: ItemTvBinding) : RecyclerView.ViewHolder(binding.root),
        View.OnClickListener {

        init {
            // Set an OnClickListener for the whole item view
            binding.root.setOnClickListener(this)
        }

        // Handle item click and navigate to TvDetailActivity with the selected TV show
        override fun onClick(v: View?) {
            val tv = tvs[absoluteAdapterPosition]
            val intent = Intent(context, TvDetailActivity::class.java).apply {
                putExtra(TV_EXTRA, tv)
            }
            context.startActivity(intent)
        }

        /**
         * Bind TV show data to the views.
         * @param tv Tv object to be displayed.
         */
        fun bind(tv: Tv) {
            binding.apply {
                // Set the TV show title
                mediaTitle.text = tv.title
                // Set the TV show rate with a formatted string
                mediaRate.text = context.getString(R.string.rate_label, tv.vote.toString())

                // Load TV show poster using Glide with rounded corners
                Glide.with(context)
                    .load("${context.getString(R.string.image_base_url)}${tv.poster_path}")
                    .centerCrop()
                    .transform(RoundedCorners(context.resources.getDimensionPixelSize(R.dimen.rounded_corner_radius)))
                    .into(mediaImage)
            }
        }
    }
}
