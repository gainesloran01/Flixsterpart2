# Android project - Flixster Part 2

**Movie and TV show horizontal list**

The app provides the top movies and TV shows through API call.

---

Made by Jaisai Reddy
